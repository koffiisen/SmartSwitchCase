from .smartswitchcase import SmartSwitchCase, Case
